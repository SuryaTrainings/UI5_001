sap.ui.define([
    "st/b33/SimpleApp/controller/BaseController"
], function(BaseController) {
    'use strict';
    return BaseController.extend("st.b33.SimpleApp.controller.App", {
        
        
    })
});